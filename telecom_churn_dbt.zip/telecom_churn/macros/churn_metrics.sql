{#
  Shared aggregate block so every churn report calculates the metrics
  exactly the same way. Use it inside a GROUP BY query.
  churn_rate = churned customers / all customers in the segment.
#}
{% macro churn_metrics() %}
    count(*)                                                        as total_customers,
    sum(is_churned)                                                 as churned_customers,
    sum(is_stayed)                                                  as stayed_customers,
    sum(is_joined)                                                  as joined_customers,
    round(sum(is_churned) * 100.0 / count(*), 2)                    as churn_rate_pct,
    round(avg(tenure_months), 1)                                    as avg_tenure_months,
    round(avg(case when has_valid_monthly_charge then monthly_charge end), 2) as avg_monthly_charge,
    round(sum(total_revenue), 2)                                    as total_revenue,
    round(sum(case when is_churned = 1 then total_revenue else 0 end), 2) as revenue_from_churned
{% endmacro %}
