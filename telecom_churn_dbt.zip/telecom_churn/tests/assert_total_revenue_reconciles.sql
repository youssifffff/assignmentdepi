-- Total Revenue must equal Charges - Refunds + Extra Data + Long Distance (per data dictionary).
select customer_id
from {{ ref('stg_customer_churn') }}
where abs(total_revenue - (total_charges - total_refunds + total_extra_data_charges + total_long_distance_charges)) > 0.01
