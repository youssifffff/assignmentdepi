-- Every report must account for exactly the same customer / churn counts as the fact table.
with expected as (
    select count(*) as c, sum(is_churned) as ch from {{ ref('fct_customers') }}
),
reports as (
    select 'contract'   as r, sum(total_customers) c, sum(churned_customers) ch from {{ ref('rpt_churn_by_contract_billing') }}
    union all select 'demographics', sum(total_customers), sum(churned_customers) from {{ ref('rpt_churn_by_demographics') }}
    union all select 'service',      sum(total_customers), sum(churned_customers) from {{ ref('rpt_churn_by_service') }}
    union all select 'tenure_offer', sum(total_customers), sum(churned_customers) from {{ ref('rpt_churn_by_tenure_offer') }}
    union all select 'geography',    sum(total_customers), sum(churned_customers) from {{ ref('rpt_churn_by_geography') }}
    union all select 'population',   sum(total_customers), sum(churned_customers) from {{ ref('rpt_churn_by_population_band') }}
)
select r from reports, expected
where reports.c <> expected.c or reports.ch <> expected.ch
