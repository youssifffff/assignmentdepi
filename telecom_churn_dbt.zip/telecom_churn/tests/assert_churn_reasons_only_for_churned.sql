-- Churn category/reason should exist if and only if the customer churned.
select customer_id
from {{ ref('stg_customer_churn') }}
where (customer_status = 'Churned') <> (churn_category is not null)
