-- Lifecycle view: how long they've been with us and the last offer accepted.
select
    tenure_group,
    offer,
    {{ churn_metrics() }}
from {{ ref('fct_customers') }}
group by 1, 2
order by churn_rate_pct desc
