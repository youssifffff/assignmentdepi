-- Rolled up by zip population band (urban density proxy).
select
    zip_population_band,
    {{ churn_metrics() }}
from {{ ref('fct_customers') }}
group by 1
order by churn_rate_pct desc
