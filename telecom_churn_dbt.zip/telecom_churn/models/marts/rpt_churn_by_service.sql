-- Which products / plans are associated with churn.
select
    service_bundle,
    internet_type,
    has_unlimited_data,
    has_premium_tech_support,
    num_addon_services,
    {{ churn_metrics() }}
from {{ ref('fct_customers') }}
group by 1, 2, 3, 4, 5
order by churn_rate_pct desc
