-- Why customers leave: category and specific reason, with share of all churn.
with churned as (

    select * from {{ ref('fct_customers') }} where is_churned = 1

)

select
    churn_category,
    churn_reason,
    count(*)                                                      as churned_customers,
    round(count(*) * 100.0 / sum(count(*)) over (), 2)            as pct_of_all_churn,
    round(avg(tenure_months), 1)                                  as avg_tenure_months,
    round(sum(total_revenue), 2)                                  as revenue_lost_to_date
from churned
group by 1, 2
order by churned_customers desc
