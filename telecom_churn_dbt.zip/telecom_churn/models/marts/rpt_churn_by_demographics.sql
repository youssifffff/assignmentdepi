-- Who churns: age group, gender, marital status, dependents.
select
    age_group,
    gender,
    is_married,
    case when number_of_dependents > 0 then 'Has dependents' else 'No dependents' end as dependents_group,
    {{ churn_metrics() }}
from {{ ref('fct_customers') }}
group by 1, 2, 3, 4
order by churn_rate_pct desc
