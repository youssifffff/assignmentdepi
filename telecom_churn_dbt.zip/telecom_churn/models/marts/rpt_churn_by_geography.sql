-- City / zip level churn, joined with zip population for segmentation.
select
    city,
    zip_code,
    zip_population,
    zip_population_band,
    {{ churn_metrics() }},
    round(count(*) * 1000.0 / nullif(zip_population, 0), 2) as customers_per_1k_population
from {{ ref('fct_customers') }}
group by 1, 2, 3, 4
order by churned_customers desc
