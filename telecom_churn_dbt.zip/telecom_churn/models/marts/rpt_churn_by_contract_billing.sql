-- Contract type x payment method x paperless billing.
select
    contract,
    payment_method,
    has_paperless_billing,
    {{ churn_metrics() }}
from {{ ref('fct_customers') }}
group by 1, 2, 3
order by churn_rate_pct desc
