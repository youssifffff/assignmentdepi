-- One row per customer, analysis-ready. Base for every report below.
select * from {{ ref('int_customers_enriched') }}
