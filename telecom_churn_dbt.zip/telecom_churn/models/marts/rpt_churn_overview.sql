-- Single-row KPI summary for the whole customer base.
select
    {{ churn_metrics() }},
    round(avg(case when is_churned = 1 then monthly_charge end), 2) as avg_monthly_charge_churned,
    round(avg(case when is_stayed  = 1 then monthly_charge end), 2) as avg_monthly_charge_stayed
from {{ ref('fct_customers') }}
