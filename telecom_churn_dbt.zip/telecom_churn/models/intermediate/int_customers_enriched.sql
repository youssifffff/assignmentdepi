-- Joins customers to zip population and derives the flags / segments
-- that all reporting models group by.
with customers as (

    select * from {{ ref('stg_customer_churn') }}

),

zips as (

    select * from {{ ref('stg_zipcode_population') }}

)

select
    c.*,
    z.population                                         as zip_population,

    -- outcome flags (1/0 so they can be summed)
    case when c.customer_status = 'Churned' then 1 else 0 end as is_churned,
    case when c.customer_status = 'Stayed'  then 1 else 0 end as is_stayed,
    case when c.customer_status = 'Joined'  then 1 else 0 end as is_joined,

    -- data quality: 120 customers have a negative monthly charge in the source
    (c.monthly_charge >= 0)                              as has_valid_monthly_charge,

    -- segments
    case
        when c.age < 25 then '18-24'
        when c.age < 35 then '25-34'
        when c.age < 45 then '35-44'
        when c.age < 55 then '45-54'
        when c.age < 65 then '55-64'
        else '65+'
    end                                                  as age_group,

    case
        when c.tenure_months <= 6  then '0-6 months'
        when c.tenure_months <= 12 then '7-12 months'
        when c.tenure_months <= 24 then '13-24 months'
        when c.tenure_months <= 48 then '25-48 months'
        else '49+ months'
    end                                                  as tenure_group,

    case
        when z.population < 10000  then 'Small (<10k)'
        when z.population < 30000  then 'Medium (10k-30k)'
        when z.population < 60000  then 'Large (30k-60k)'
        else 'Very large (60k+)'
    end                                                  as zip_population_band,

    case
        when not c.has_internet_service and not c.has_phone_service then 'No service'
        when c.has_internet_service and c.has_phone_service         then 'Phone + Internet'
        when c.has_internet_service                                 then 'Internet only'
        else 'Phone only'
    end                                                  as service_bundle,

    (c.has_online_security::int + c.has_online_backup::int + c.has_device_protection_plan::int
     + c.has_premium_tech_support::int)                  as num_addon_services

from customers c
left join zips z using (zip_code)
