select
    lpad(cast("Zip Code" as varchar), 5, '0') as zip_code,
    cast("Population" as integer)             as population
from {{ ref('raw_zipcode_population') }}
