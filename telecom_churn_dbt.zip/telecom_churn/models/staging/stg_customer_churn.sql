-- Staging: 1:1 with the source file. Rename to snake_case, cast types,
-- standardise categoricals. No business logic here.
with source as (

    select * from {{ ref('raw_customer_churn') }}

)

select
    "Customer ID"                                   as customer_id,
    "Gender"                                        as gender,
    cast("Age" as integer)                          as age,
    ("Married" = 'Yes')                             as is_married,
    cast("Number of Dependents" as integer)         as number_of_dependents,

    "City"                                          as city,
    lpad(cast("Zip Code" as varchar), 5, '0')       as zip_code,
    cast("Latitude" as double)                      as latitude,
    cast("Longitude" as double)                     as longitude,

    cast("Number of Referrals" as integer)          as number_of_referrals,
    cast("Tenure in Months" as integer)             as tenure_months,
    coalesce("Offer", 'None')                       as offer,

    -- phone
    ("Phone Service" = 'Yes')                       as has_phone_service,
    coalesce(cast("Avg Monthly Long Distance Charges" as double), 0) as avg_monthly_long_distance_charges,
    coalesce("Multiple Lines" = 'Yes', false)       as has_multiple_lines,

    -- internet
    ("Internet Service" = 'Yes')                    as has_internet_service,
    coalesce("Internet Type", 'None')               as internet_type,
    coalesce(cast("Avg Monthly GB Download" as double), 0) as avg_monthly_gb_download,
    coalesce("Online Security" = 'Yes', false)      as has_online_security,
    coalesce("Online Backup" = 'Yes', false)        as has_online_backup,
    coalesce("Device Protection Plan" = 'Yes', false) as has_device_protection_plan,
    coalesce("Premium Tech Support" = 'Yes', false) as has_premium_tech_support,
    coalesce("Streaming TV" = 'Yes', false)         as has_streaming_tv,
    coalesce("Streaming Movies" = 'Yes', false)     as has_streaming_movies,
    coalesce("Streaming Music" = 'Yes', false)      as has_streaming_music,
    coalesce("Unlimited Data" = 'Yes', false)       as has_unlimited_data,

    -- billing
    "Contract"                                      as contract,
    ("Paperless Billing" = 'Yes')                   as has_paperless_billing,
    "Payment Method"                                as payment_method,
    cast("Monthly Charge" as double)                as monthly_charge,
    cast("Total Charges" as double)                 as total_charges,
    cast("Total Refunds" as double)                 as total_refunds,
    cast("Total Extra Data Charges" as double)      as total_extra_data_charges,
    cast("Total Long Distance Charges" as double)   as total_long_distance_charges,
    cast("Total Revenue" as double)                 as total_revenue,

    -- outcome
    "Customer Status"                               as customer_status,
    "Churn Category"                                as churn_category,
    "Churn Reason"                                  as churn_reason

from source
