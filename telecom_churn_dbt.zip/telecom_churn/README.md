# Telecom Churn Reporting Model (dbt + DuckDB)

## Run it
```bash
pip install dbt-duckdb
dbt seed --profiles-dir .
dbt run  --profiles-dir .
dbt test --profiles-dir .
dbt docs generate --profiles-dir . && dbt docs serve --profiles-dir .
```
(To use Snowflake/BigQuery/Postgres, just change `profiles.yml`; the SQL is standard.)

## Lineage
seeds (raw_customer_churn, raw_zipcode_population)
 -> staging (stg_customer_churn, stg_zipcode_population)   rename, cast, standardise
 -> intermediate (int_customers_enriched)                   join zip population, flags, segments
 -> marts (fct_customers + 8 rpt_churn_* reports)

## Decisions
- churn_rate_pct = churned / all customers in the segment (Joined customers included in denominator).
- 120 customers have a negative Monthly Charge: kept (not deleted), flagged with `has_valid_monthly_charge`, excluded from avg_monthly_charge.
- Nulls that mean "no service" (internet add-ons, multiple lines, GB download, long distance) -> false / 0; Offer & Internet Type -> 'None' (per data dictionary).
- Zip codes zero-padded to 5 digits before joining; all 7,043 customers match a zip.
- The shared metric block lives in `macros/churn_metrics.sql` so all reports calculate identically.

## Tests (24 passing)
unique / not_null / accepted_values on staging and marts + 3 singular tests
(revenue reconciles to the data dictionary formula, churn reason only for churned customers, every report's totals match the fact table).
